from collections import defaultdict
import re


# --------------------------------------------------
# BUILD FUNCTION RELATIONSHIP GRAPH
# --------------------------------------------------

def build_graph(functions):
    """
    Creates a simple relationship graph:
    function -> where it appears / relates
    """

    graph = defaultdict(set)

    for f in functions:
        name = f["name"]
        raw = f.get("raw_signature", "")
        file = f.get("file", "")

        # basic heuristic: function "connects" to others via name mentions
        for other in functions:
            if f == other:
                continue

            if name in other.get("raw_signature", ""):
                graph[name].add(other["name"])

    # convert sets → lists for JSON safety
    return {k: list(v) for k, v in graph.items()}


# --------------------------------------------------
# OPTIONAL: SIMPLE IMPORT GRAPH (LIGHTWEIGHT)
# --------------------------------------------------

def extract_imports(file_text):
    """
    Very lightweight import detection (Python only)
    """
    imports = []

    for line in file_text.splitlines():
        line = line.strip()

        if line.startswith("import "):
            imports.append(line)
        elif line.startswith("from "):
            imports.append(line)

    return imports


# --------------------------------------------------
# ENRICH GRAPH WITH FILE DATA
# --------------------------------------------------

def build_file_graph(files):
    """
    Maps file → imports (basic architecture view)
    """

    file_graph = {}

    for file_path in files:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception:
            continue

        file_graph[str(file_path)] = extract_imports(content)

    return file_graph
