from dataclasses import dataclass

@dataclass
class PipelineContext:
    path: str

    # analysis output
    files: list = None
    functions: dict = None
    groups: dict = None
    call_graph: dict = None
    usage_map: dict = None

    # planning output
    stable_groups: list = None
    safe_groups: list = None

    # execution state
    applied_groups: list = None
    branch: str = None

    # runtime flags
    dry_run: bool = False
