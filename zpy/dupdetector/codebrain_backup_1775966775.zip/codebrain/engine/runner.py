from codebrain.scanner import scan_files
from codebrain.analyzer import analyze_files, group_duplicates
from codebrain.call_graph import build_call_graph, build_usage_map, filter_safe_groups

from codebrain.safe_refactor import update_stability, apply_safe_refactor
from codebrain.dependency_refactor import update_function_calls, update_imports
from codebrain.test_runner import run_tests
from codebrain.git_layer import ensure_git_repo, create_snapshot

import time
import traceback


# --------------------------------------------------
# ENGINE CORE
# --------------------------------------------------

class Engine:

    def run(self, ctx):

        print("\n🚀 CODEBRAIN ENGINE v1\n")

        ensure_git_repo(ctx.path)

        print("\n🧪 Pre-check tests...")
        ok, _ = run_tests(ctx.path)

        if not ok:
            print("❌ Tests failing — abort")
            return False

        ctx.files = scan_files(ctx.path)
        ctx.functions = analyze_files(ctx.files)
        ctx.groups = group_duplicates(ctx.functions)

        ctx.call_graph = build_call_graph(ctx.files)
        ctx.usage_map = build_usage_map(ctx.call_graph)

        ctx.stable_groups = update_stability(ctx.groups)

        confident = [(k, v, 1.0) for k, v in ctx.groups.items() if len(v) > 1]
        ctx.safe_groups = filter_safe_groups(confident, ctx.usage_map)

        if not ctx.safe_groups:
            print("ℹ️ Nothing safe to refactor")
            return True

        ctx.applied_groups = []

        create_snapshot(ctx.path, "Pre-refactor snapshot")

        for _, group, _ in ctx.safe_groups:

            print(f"\n🤖 Processing group: {group[0]['name']}")

            apply_safe_refactor([group])

            for func in group[1:]:
                update_function_calls(ctx.path, func["name"], group[0]["name"])
                update_imports(ctx.path, func["name"], group[0]["name"])

            ctx.applied_groups.append(group)

        print("\n🧪 Post-check tests...")
        ok, _ = run_tests(ctx.path)

        if not ok:
            print("❌ Failed — rollback recommended")
            return False

        create_snapshot(ctx.path, "Post-refactor snapshot")

        print("\n✅ ENGINE COMPLETE\n")
        return True


# --------------------------------------------------
# CONTEXT WRAPPER
# --------------------------------------------------

class Context:
    def __init__(self, path):
        self.path = path


_engine = Engine()


# --------------------------------------------------
# PUBLIC API
# --------------------------------------------------

def run_pipeline(path):
    ctx = Context(path)
    return _engine.run(ctx)


def run_auto(path, interval=300):
    print(f"\n🔁 Auto mode enabled (interval: {interval}s)")
    print("Press Ctrl+C to stop.\n")

    iteration = 1

    try:
        while True:
            print(f"\n🔄 Auto iteration #{iteration}")

            try:
                success = run_pipeline(path)

                if not success:
                    print("⚠️ Pipeline reported failure")

            except Exception as e:
                print("❌ Exception during pipeline run:")
                print(f"   {e}")
                traceback.print_exc()

            print(f"\n⏳ Waiting {interval}s before next run...\n")
            time.sleep(interval)
            iteration += 1

    except KeyboardInterrupt:
        print("\n🛑 Auto mode stopped by user\n")
