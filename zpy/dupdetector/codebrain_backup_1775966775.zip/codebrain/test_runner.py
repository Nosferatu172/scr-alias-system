import subprocess


def run_tests(project_path):
    """
    Runs tests in the project directory
    """

    try:
        result = subprocess.run(
            ["pytest"],
            cwd=project_path,
            capture_output=True,
            text=True
        )

        success = result.returncode == 0

        return success, result.stdout + result.stderr

    except Exception as e:
        return False, str(e)
