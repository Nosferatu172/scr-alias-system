import subprocess
from pathlib import Path


# --------------------------------------------------
# CHECK IF GIT EXISTS
# --------------------------------------------------

def is_git_repo(path):
    return (Path(path) / ".git").exists()


def run_git_command(path, args):
    return subprocess.run(
        ["git"] + args,
        cwd=path,
        capture_output=True,
        text=True
    )


# --------------------------------------------------
# INIT REPO IF NEEDED
# --------------------------------------------------

def ensure_git_repo(path):
    if not is_git_repo(path):
        print("🛠 Initializing git repository...")
        run_git_command(path, ["init"])
        run_git_command(path, ["add", "."])
        run_git_command(path, ["commit", "-m", "Initial snapshot (auto)"])
        print("✔ Git initialized")


# --------------------------------------------------
# SAFE SNAPSHOT
# --------------------------------------------------

def create_snapshot(path, message):
    run_git_command(path, ["add", "."])
    run_git_command(path, ["commit", "-m", message])


# --------------------------------------------------
# ROLLBACK
# --------------------------------------------------

def rollback_last(path):
    print("⚠️ Rolling back last change...")
    run_git_command(path, ["reset", "--hard", "HEAD~1"])
    print("✔ Rollback complete")

# ==================================================
# bot
# ==================================================
def create_branch(path, name):
    run_git_command(path, ["checkout", "-b", name])


def checkout_main(path):
    run_git_command(path, ["checkout", "main"])


def get_current_branch(path):
    result = run_git_command(path, ["rev-parse", "--abbrev-ref", "HEAD"])
    return result.stdout.strip()
