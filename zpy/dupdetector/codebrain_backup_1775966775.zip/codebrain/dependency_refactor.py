import re
from pathlib import Path


# --------------------------------------------------
# UPDATE FUNCTION CALLS ACROSS PROJECT
# --------------------------------------------------

def update_function_calls(project_path, old_name, new_name):
    """
    Replaces function calls across all files
    """

    for path in Path(project_path).rglob("*.py"):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            updated = re.sub(rf"\b{old_name}\b", new_name, content)

            if updated != content:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(updated)

        except Exception:
            continue


# --------------------------------------------------
# UPDATE IMPORTS
# --------------------------------------------------

def update_imports(project_path, old_name, new_name):
    """
    Fix import statements
    """

    for path in Path(project_path).rglob("*.py"):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()

            new_lines = []

            for line in lines:
                if "import" in line or "from" in line:
                    line = line.replace(old_name, new_name)

                new_lines.append(line)

            with open(path, "w", encoding="utf-8") as f:
                f.writelines(new_lines)

        except Exception:
            continue
