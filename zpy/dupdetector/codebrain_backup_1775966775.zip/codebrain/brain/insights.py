def detect_architecture_smells(dependency_map):
    """
    Detects structural issues in the codebase
    """

    smells = []

    for func, deps in dependency_map.items():

        # too many dependencies = complex function
        if len(deps) > 5:
            smells.append({
                "type": "god_function",
                "function": func,
                "severity": "high"
            })

        # no dependencies = possibly unused
        if len(deps) == 0:
            smells.append({
                "type": "dead_code",
                "function": func,
                "severity": "medium"
            })

    return smells


def suggest_refactors(smells):
    """
    Generates human-readable suggestions
    """

    suggestions = []

    for s in smells:

        if s["type"] == "god_function":
            suggestions.append(
                f"⚠️ Split '{s['function']}' into smaller functions"
            )

        elif s["type"] == "dead_code":
            suggestions.append(
                f"🧹 Consider removing unused function '{s['function']}'"
            )

    return suggestions
