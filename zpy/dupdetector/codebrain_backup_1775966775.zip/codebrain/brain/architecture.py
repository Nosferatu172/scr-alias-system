from collections import defaultdict


# --------------------------------------------------
# BUILD DEPENDENCY MAP
# --------------------------------------------------

def build_dependency_map(functions):
    """
    Creates a map:
    function -> functions it appears to depend on
    """

    graph = defaultdict(set)

    for f in functions:
        name = f["name"]
        raw = f.get("raw_signature", "")

        for other in functions:
            if f == other:
                continue

            # simple heuristic: if name appears in another signature
            if name in other.get("raw_signature", ""):
                graph[name].add(other["name"])

    return {k: list(v) for k, v in graph.items()}
