import ast
from collections import defaultdict


# --------------------------------------------------
# CALL GRAPH (PURE ANALYSIS)
# --------------------------------------------------

def build_call_graph(files):
    """
    Maps function -> functions it calls
    (PURE ANALYSIS ONLY)
    """

    graph = defaultdict(set)

    for file_path in files:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                tree = ast.parse(f.read())
        except Exception:
            continue

        current_func = None

        for node in ast.walk(tree):

            if isinstance(node, ast.FunctionDef):
                current_func = node.name

            elif isinstance(node, ast.Call) and current_func:
                if isinstance(node.func, ast.Name):
                    graph[current_func].add(node.func.id)

    return {k: list(v) for k, v in graph.items()}


# --------------------------------------------------
# USAGE MAP (PURE ANALYSIS)
# --------------------------------------------------

def build_usage_map(call_graph):
    usage = defaultdict(int)

    for caller, callees in call_graph.items():
        for callee in callees:
            usage[callee] += 1

    return dict(usage)


# --------------------------------------------------
# RISK SCORING (SEPARATE CONCERN)
# --------------------------------------------------

def assess_risk(group, usage_map):
    risk_score = 0

    for func in group:
        usage = usage_map.get(func["name"], 0)

        if usage > 5:
            risk_score += 2
        elif usage > 2:
            risk_score += 1

    return risk_score


# --------------------------------------------------
# POLICY FILTER (HIGH LEVEL DECISION LAYER)
# --------------------------------------------------

def filter_safe_groups(confident_groups, usage_map, max_risk=2):
    """
    NOTE:
    This is now explicitly a POLICY function.
    It should NOT be imported by low-level analysis modules.
    """

    safe = []

    for key, group, score in confident_groups:
        risk = assess_risk(group, usage_map)

        if risk <= max_risk:
            safe.append((key, group, score))
        else:
            print(f"⚠️ Skipping high-risk group: {group[0]['name']} (risk={risk})")

    return safe
