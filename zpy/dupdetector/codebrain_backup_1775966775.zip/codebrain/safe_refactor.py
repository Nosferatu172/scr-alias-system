import json
from pathlib import Path

from codebrain.core.rewriter import replace_function

STATE_FILE = Path("evolve/refactor_state.json")


# --------------------------------------------------
# LOAD / SAVE STATE
# --------------------------------------------------

def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, "r") as f:
                return json.load(f)
        except:
            return {}
    return {}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


# --------------------------------------------------
# TRACK DUPLICATE STABILITY
# --------------------------------------------------

def update_stability(groups):
    state = load_state()

    for key, funcs in groups.items():
        if len(funcs) < 2:
            continue

        state[key] = state.get(key, 0) + 1

    save_state(state)
    return state


# --------------------------------------------------
# SELECT SAFE REFACTOR TARGETS
# --------------------------------------------------

def get_stable_groups(groups, state, min_runs=3):
    stable = []

    for key, funcs in groups.items():
        if len(funcs) < 2:
            continue

        if state.get(key, 0) >= min_runs:
            stable.append(funcs)

    return stable


# --------------------------------------------------
# APPLY SAFE REFACTOR
# --------------------------------------------------

def apply_safe_refactor(stable_groups):
    print("\n🛠 Applying SAFE refactors...\n")

    for group in stable_groups:

        canonical = group[0]
        canonical_name = canonical["name"]

        try:
            with open(canonical["file"], "r", encoding="utf-8") as f:
                canonical_code = f.read()
        except:
            continue

        for func in group[1:]:

            try:
                with open(func["file"], "r", encoding="utf-8") as f:
                    content = f.read()

                updated = replace_function(
                    content,
                    func["name"],
                    canonical_name,
                    canonical_code
                )

                backup_path = func["file"] + ".bak"
                with open(backup_path, "w") as b:
                    b.write(content)

                with open(func["file"], "w") as f:
                    f.write(updated)

                print(f"✔ Refactored: {func['file']} ({func['name']})")

            except Exception as e:
                print(f"❌ Skipped {func['file']} ({e})")
