import ast
from difflib import SequenceMatcher


# --------------------------------------------------
# FUNCTION EXTRACTION
# --------------------------------------------------

class FunctionExtractor(ast.NodeVisitor):
    def __init__(self):
        self.functions = []

    def visit_FunctionDef(self, node):
        self.functions.append(self._build_function(node))
        self.generic_visit(node)

    def _build_function(self, node):
        ops = []

        for n in ast.walk(node):
            if isinstance(n, ast.BinOp):
                ops.append(type(n.op).__name__)
            elif isinstance(n, ast.Call):
                ops.append("Call")
            elif isinstance(n, ast.Return):
                ops.append("Return")
            elif isinstance(n, ast.If):
                ops.append("If")
            elif isinstance(n, ast.For):
                ops.append("For")
            elif isinstance(n, ast.While):
                ops.append("While")

        raw_signature = f"{node.name}|args:{len(node.args.args)}|ops:{sorted(ops)}"

        return {
            "name": node.name,
            "line": node.lineno,
            "raw_signature": raw_signature,
            "file": None  # filled later
        }


# --------------------------------------------------
# FILE ANALYSIS
# --------------------------------------------------

def analyze_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            tree = ast.parse(f.read())
    except SyntaxError:
        return []

    extractor = FunctionExtractor()
    extractor.visit(tree)

    return extractor.functions


def analyze_files(files):
    all_functions = []

    for file in files:
        funcs = analyze_file(file)

        for f in funcs:
            f["file"] = str(file)

        all_functions.extend(funcs)

    return all_functions


# --------------------------------------------------
# EXACT DUPLICATES
# --------------------------------------------------

def group_duplicates(functions):
    groups = {}

    for f in functions:
        key = f["raw_signature"]
        groups.setdefault(key, []).append(f)

    return groups


# --------------------------------------------------
# NEAR DUPLICATES
# --------------------------------------------------

def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def find_near_duplicates(functions, threshold=0.85):
    matches = []

    for i in range(len(functions)):
        for j in range(i + 1, len(functions)):
            f1 = functions[i]
            f2 = functions[j]

            score = similarity(f1["raw_signature"], f2["raw_signature"])

            if score >= threshold:
                matches.append({
                    "score": round(score * 100, 2),
                    "a": f1,
                    "b": f2
                })

    return matches
