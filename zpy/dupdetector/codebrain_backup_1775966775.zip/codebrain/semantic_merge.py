import ast


def extract_function_ast(file_path, func_name):
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        tree = ast.parse(f.read())

    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            return node

    return None


def merge_ast_functions(func_group):
    """
    Attempts AST-level merge of functions
    """

    base_func = func_group[0]
    base_node = extract_function_ast(base_func["file"], base_func["name"])

    if not base_node:
        raise Exception("Base function AST not found")

    merged_body = list(base_node.body)

    # collect unique statements from other functions
    for func in func_group[1:]:
        node = extract_function_ast(func["file"], func["name"])

        if not node:
            continue

        for stmt in node.body:
            if not any(ast.dump(stmt) == ast.dump(existing) for existing in merged_body):
                merged_body.append(stmt)

    base_node.body = merged_body

    try:
        merged_code = ast.unparse(base_node)
    except Exception:
        raise Exception("AST unparsing failed")

    return merged_code
