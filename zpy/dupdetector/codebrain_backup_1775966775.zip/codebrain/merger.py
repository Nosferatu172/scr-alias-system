# merger.py

def build_canonical_function(group):
    """
    Chooses best function and makes it canonical
    """
    sorted_funcs = sorted(group, key=lambda f: len(f["raw_signature"]), reverse=True)
    return sorted_funcs[0]


def generate_merge_plan(groups):
    plan = []

    for sig, funcs in groups.items():
        if len(funcs) < 2:
            continue

        canonical = build_canonical_function(funcs)

        plan.append({
            "canonical": canonical,
            "duplicates": [f for f in funcs if f != canonical]
        })

    return plan
