#!/usr/bin/env bash
set -e

ROOT="$(pwd)"
BACKUP_DIR="$ROOT/legacy_lock_$(date +%s)"

echo "🧠======================================"
echo "   CODEBRAIN ARCHITECTURE LOCK"
echo "======================================"
echo "📍 Root: $ROOT"
echo ""

mkdir -p "$BACKUP_DIR"

# --------------------------------------------------
# STEP 1 — DETECT INVALID ARCHITECTURE FILES
# --------------------------------------------------

echo "🔍 Scanning for broken / duplicate pipeline sources..."

BROKEN=$(grep -R "run_pipeline" -n codebrain | grep -v "engine/runner.py" || true)

if [ ! -z "$BROKEN" ]; then
    echo "⚠️ Multiple pipeline definitions detected:"
    echo "$BROKEN"
fi

# --------------------------------------------------
# STEP 2 — FORCE main.py CLEAN STATE
# --------------------------------------------------

echo ""
echo "🧹 Locking main.py to CLI-only mode..."

cat > codebrain/main.py << 'EOF'
#!/usr/bin/env python3

import argparse
from codebrain.engine.runner import run_pipeline

def main():
    parser = argparse.ArgumentParser(add_help=False)

    parser.add_argument("path", nargs="?", help="Project path")
    parser.add_argument("--auto", action="store_true")
    parser.add_argument("--interval", type=int, default=300)
    parser.add_argument("--help", action="store_true")

    args = parser.parse_args()

    if args.help or not args.path:
        from codebrain.help_text import HELP_TEXT
        print(HELP_TEXT)
        return

    if args.auto:
        from codebrain.engine.runner import run_auto
        run_auto(args.path, args.interval)
    else:
        run_pipeline(args.path)

if __name__ == "__main__":
    main()
EOF

echo "✔ main.py locked"

# --------------------------------------------------
# STEP 3 — PATCH RUNNER (REMOVE DEAD IMPORT CRASHES)
# --------------------------------------------------

echo ""
echo "🧠 Ensuring runner.py has no fatal imports..."

if grep -q "RuntimeError(\"runner.py is deprecated" codebrain/engine/runner.py; then
    echo "→ Removing deprecated crash guard"
    sed -i '/RuntimeError("runner.py is deprecated/d' codebrain/engine/runner.py
fi

# --------------------------------------------------
# STEP 4 — VERIFY SINGLE PIPELINE ENTRYPOINT
# --------------------------------------------------

echo ""
echo "🔍 Verifying pipeline uniqueness..."

COUNT=$(grep -R "def run_pipeline" codebrain | wc -l)

if [ "$COUNT" -ne 1 ]; then
    echo "❌ ERROR: run_pipeline is duplicated ($COUNT occurrences)"
    echo "Move extra definitions into runner.py only."
else
    echo "✔ Single pipeline entry confirmed"
fi

# --------------------------------------------------
# STEP 5 — CHECK IMPORT CONSISTENCY
# --------------------------------------------------

echo ""
echo "🔍 Checking import consistency..."

grep -R "codebrain.analysis" codebrain || echo "✔ No invalid analysis imports found"
grep -R "planning" codebrain || echo "✔ No legacy planning imports found"
grep -R "execution" codebrain || echo "✔ No legacy execution imports found"

# --------------------------------------------------
# STEP 6 — FINAL SANITY CHECK
# --------------------------------------------------

echo ""
echo "🧪 Import test..."

python3 - << 'EOF'
import codebrain.main
print("✔ CodeBrain import OK")
EOF

# --------------------------------------------------
# DONE
# --------------------------------------------------

echo ""
echo "🧠======================================"
echo "✔ ARCHITECTURE LOCK COMPLETE"
echo "======================================"
echo ""
echo "Backup (if anything broke):"
echo "  $BACKUP_DIR"
echo ""
echo "Next step:"
echo "  run: codebrain <path>"
echo "======================================"
