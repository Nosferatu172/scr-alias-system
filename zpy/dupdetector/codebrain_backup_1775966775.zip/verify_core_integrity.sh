#!/usr/bin/env bash
set -e

echo "🧠======================================"
echo "   CODEBRAIN CORE INTEGRITY CHECK"
echo "======================================"

ROOT="$(pwd)"

# --------------------------------------------------
# STEP 1 — Python import sanity
# --------------------------------------------------

echo "🐍 Checking Python package import..."

python3 - << 'EOF'
import sys
sys.path.insert(0, ".")

try:
    import codebrain.main
    print("✔ codebrain.main imports OK")
except Exception as e:
    print("❌ main import failed:", e)
    exit(1)

try:
    import codebrain.scanner
    import codebrain.analyzer
    import codebrain.call_graph
    import codebrain.safe_refactor
    import codebrain.test_runner
    print("✔ core modules import OK")
except Exception as e:
    print("❌ core module failure:", e)
    exit(1)
EOF

# --------------------------------------------------
# STEP 2 — detect forbidden architecture drift
# --------------------------------------------------

echo ""
echo "🔍 Checking for forbidden architecture paths..."

BAD=$(grep -R "codebrain\.planning\|codebrain\.execution\|codebrain\.safety" codebrain || true)

if [ ! -z "$BAD" ]; then
    echo "❌ Architecture drift detected:"
    echo "$BAD"
    exit 1
fi

echo "✔ No forbidden architecture namespaces"

# --------------------------------------------------
# STEP 3 — CLI sanity
# --------------------------------------------------

echo ""
echo "⚙ Testing CLI help..."

codebrain --help >/dev/null 2>&1 || python3 -m codebrain.main --help >/dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "❌ CLI failed to boot"
    exit 1
fi

echo "✔ CLI boots correctly"

# --------------------------------------------------
# STEP 4 — pipeline dry-run (safe mode)
# --------------------------------------------------

echo ""
echo "🧪 Running dry pipeline test..."

python3 - << 'EOF'
import sys
sys.path.insert(0, ".")

from codebrain.scanner import scan_files
from codebrain.analyzer import analyze_files, group_duplicates

try:
    files = scan_files(".")
    funcs = analyze_files(files)
    groups = group_duplicates(funcs)

    print("✔ analysis pipeline OK")
    print(f"   files: {len(files)}")
    print(f"   functions: {len(funcs)}")
    print(f"   groups: {len(groups)}")

except Exception as e:
    print("❌ pipeline failure:", e)
    exit(1)
EOF

# --------------------------------------------------
# FINAL RESULT
# --------------------------------------------------

echo ""
echo "🧠======================================"
echo "✔ CORE INTEGRITY PASSED"
echo "======================================"
echo ""
echo "System is safe to run CodeBrain."
echo "======================================"
