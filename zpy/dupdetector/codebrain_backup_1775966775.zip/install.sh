#!/usr/bin/env bash
set -e

echo "🧠===================================="
echo "   CODEBRAIN INSTALL (CLI EDITION)"
echo "===================================="

PROJECT_ROOT="$(pwd)"
VENV_PATH="$PROJECT_ROOT/.venv"
BIN_DIR="$PROJECT_ROOT/.bin"

# --------------------------------------------------
# SYSTEM DEPENDENCIES
# --------------------------------------------------

echo "📦 Installing system deps..."

if command -v apt >/dev/null 2>&1; then
    sudo apt update
    sudo apt install -y python3 python3-venv python3-pip git
fi

# --------------------------------------------------
# VENV
# --------------------------------------------------

echo "🐍 Setting up virtual environment..."

if [ ! -d "$VENV_PATH" ]; then
    python3 -m venv "$VENV_PATH"
fi

source "$VENV_PATH/bin/activate"

pip install --upgrade pip setuptools wheel

# --------------------------------------------------
# PYTHON DEPENDENCIES
# --------------------------------------------------

echo "📚 Installing Python dependencies..."

pip install \
    numpy \
    gitpython \
    pytest \
    tqdm

if [ ! -z "$OPENAI_API_KEY" ]; then
    pip install openai
fi

# --------------------------------------------------
# INSTALL CODEBRAIN
# --------------------------------------------------

echo "🧠 Installing CodeBrain..."

pip install -e .

# --------------------------------------------------
# CREATE CLI WRAPPER (THIS IS THE KEY CHANGE)
# --------------------------------------------------

echo "⚙ Creating cb CLI..."

mkdir -p "$BIN_DIR"

cat > "$BIN_DIR/cb" << 'EOF'
#!/usr/bin/env bash

ROOT="$(pwd)"
VENV="$ROOT/.venv"

if [ -f "$VENV/bin/activate" ]; then
    source "$VENV/bin/activate"
fi

export PYTHONPATH="$ROOT"

CMD="$1"
shift || true

case "$CMD" in
    run)
        python3 -m codebrain.main "$@"
        ;;
    verify)
        bash verify_core_integrity.sh
        ;;
    lock)
        bash lock_codebrain.sh
        ;;
    heal)
        bash self_heal_codebrain.sh
        ;;
    reset)
        bash reset.sh
        ;;
    help|--help)
        echo "cb commands:"
        echo "  cb run <path>"
        echo "  cb verify"
        echo "  cb lock"
        echo "  cb heal"
        echo "  cb reset"
        ;;
    *)
        echo "Unknown command: $CMD"
        echo "Try: cb help"
        ;;
esac
EOF

chmod +x "$BIN_DIR/cb"

# --------------------------------------------------
# OPTIONAL GLOBAL LINK
# --------------------------------------------------

if [ -d "/usr/local/bin" ]; then
    echo "🔗 Linking cb globally..."
    sudo ln -sf "$BIN_DIR/cb" /usr/local/bin/cb
fi

# --------------------------------------------------
# TEST
# --------------------------------------------------

echo "🧪 Testing CLI..."

"$BIN_DIR/cb" help || true

# --------------------------------------------------
# DONE
# --------------------------------------------------

echo ""
echo "🧠===================================="
echo "✔ CODEBRAIN CLI INSTALL COMPLETE"
echo "===================================="
echo ""
echo "USAGE:"
echo "  cb run <path>"
echo "  cb verify"
echo "  cb lock"
echo "  cb heal"
echo "  cb reset"
echo ""
echo "===================================="
