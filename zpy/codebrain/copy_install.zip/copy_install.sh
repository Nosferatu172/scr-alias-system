#!/usr/bin/env bash
set -e

echo "🧠===================================="
echo "   CODEBRAIN SELF-HEALING INSTALLER"
echo "===================================="

ROOT="$(pwd)"
VENV="$ROOT/.venv"

# --------------------------------------------------
# DETECT STRUCTURE (SELF-AWARE STEP)
# --------------------------------------------------

echo "🧭 Detecting CodeBrain structure..."

if [ -d "$ROOT/codebrain/engine" ]; then
    STRUCTURE="engine_based"
elif [ -f "$ROOT/codebrain/main.py" ]; then
    STRUCTURE="legacy_main"
else
    STRUCTURE="unknown"
fi

echo "✔ Structure: $STRUCTURE"

# --------------------------------------------------
# SYSTEM DEPENDENCIES
# --------------------------------------------------

echo "📦 Installing system dependencies..."

if command -v apt >/dev/null 2>&1; then
    sudo apt update
    sudo apt install -y python3 python3-venv python3-pip git
elif command -v brew >/dev/null 2>&1; then
    brew install python git
fi

# --------------------------------------------------
# VENV SETUP
# --------------------------------------------------

echo "🐍 Setting up virtual environment..."

[ -d "$VENV" ] || python3 -m venv "$VENV"
source "$VENV/bin/activate"

pip install --upgrade pip setuptools wheel >/dev/null

# --------------------------------------------------
# INSTALL PACKAGE
# --------------------------------------------------

echo "🧠 Installing CodeBrain..."

pip install -e . >/dev/null

# --------------------------------------------------
# SELF-HEALING IMPORT FIXER
# --------------------------------------------------

echo ""
echo "🛠 Running self-healing import repair..."

python3 - << 'EOF'
import os
from pathlib import Path

ROOT = Path(".")
CB = ROOT / "codebrain"

replacements = {
    "codebrain.analysis": "codebrain",
    "codebrain.planning": "codebrain",
    "codebrain.execution": "codebrain",
    "codebrain.safety": "codebrain",
}

fixed_files = 0

for file in CB.rglob("*.py"):
    try:
        text = file.read_text()

        original = text

        for bad, good in replacements.items():
            if bad in text:
                text = text.replace(bad, good)

        if text != original:
            file.write_text(text)
            print(f"🔧 fixed imports in {file}")
            fixed_files += 1

    except Exception as e:
        print(f"⚠️ skip {file}: {e}")

print(f"\n✔ Healing complete: {fixed_files} files processed")
EOF

# --------------------------------------------------
# CORE IMPORT VALIDATION
# --------------------------------------------------

echo ""
echo "🔍 Validating core imports..."

python3 - << 'EOF'
import sys
sys.path.insert(0, ".")

try:
    import codebrain.main
    print("✔ main import OK")
except Exception as e:
    print("❌ main broken:", e)
    exit(1)

core = [
    "codebrain.scanner",
    "codebrain.analyzer",
    "codebrain.call_graph",
    "codebrain.safe_refactor",
    "codebrain.test_runner"
]

for m in core:
    try:
        __import__(m)
        print(f"✔ {m}")
    except Exception as e:
        print(f"❌ {m} failed:", e)
        exit(1)

print("\n✔ Core system healthy")
EOF

# --------------------------------------------------
# OPTIONAL: ARCHITECTURE CHECK
# --------------------------------------------------

echo ""
echo "🧠 Running architecture integrity check..."

if [ -f "verify_core_integrity.sh" ]; then
    bash verify_core_integrity.sh
else
    echo "⚠️ integrity checker missing"
fi

# --------------------------------------------------
# CLI WRAPPER
# --------------------------------------------------

echo ""
echo "⚙ Installing CLI wrapper..."

mkdir -p "$ROOT/.bin"

cat > "$ROOT/.bin/codebrain" << 'EOF'
#!/usr/bin/env bash

ROOT="$(pwd)"
VENV="$ROOT/.venv"

source "$VENV/bin/activate" 2>/dev/null || true

export PYTHONPATH="$ROOT"

python3 -m codebrain.main "$@"
EOF

chmod +x "$ROOT/.bin/codebrain"

# --------------------------------------------------
# FINAL TEST
# --------------------------------------------------

echo ""
echo "🧪 Testing CLI..."

./.bin/codebrain --help >/dev/null 2>&1 || true

# --------------------------------------------------
# DONE
# --------------------------------------------------

echo ""
echo "🧠===================================="
echo "✔ SELF-HEALING INSTALL COMPLETE"
echo "===================================="
echo ""
echo "MODE DETECTED:"
echo "  $STRUCTURE"
echo ""
echo "SYSTEM STATUS:"
echo "  ✔ imports repaired (best effort)"
echo "  ✔ core modules validated"
echo "  ✔ CLI installed"
echo "===================================="