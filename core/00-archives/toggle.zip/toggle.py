#!/usr/bin/env python3
"""
SCR Path Toggle (WSL <-> MSYS2 <-> Native Linux)

Usage:
    toggle.py -wsl    # force everything to /mnt/c/scr/
    toggle.py -msys   # force everything to /c/scr/
    toggle.py -linux  # force everything to /scr/

✔ Recursive
✔ Works from script location
✔ Handles extension + no-extension text files
✔ Skips itself + junk dirs
✔ NO backups
✔ FORCE mode (fixes mixed states)
✔ Safe replacement (no double prefix issues)
✔ Built-in normalization
"""

import sys
from pathlib import Path

# ----------------------------
# CONFIG
# ----------------------------
PATH_WSL   = "/mnt/c/scr/"
PATH_MSYS  = "/c/scr/"
PATH_LINUX = "/scr/"

EXTENSIONS = (".sh", ".zsh", ".py", ".rb", ".txt")

EXCLUDE_DIRS = {
    "index/generated",
    ".git",
    "__pycache__"
}

SELF = Path(__file__).resolve()
ROOT = SELF.parent

# ----------------------------
# TEXT FILE CHECK
# ----------------------------
def is_text_file(file: Path):
    try:
        with file.open("r", encoding="utf-8") as f:
            f.read(512)
        return True
    except:
        return False

# ----------------------------
# EXCLUSION CHECK
# ----------------------------
def is_excluded(file: Path):
    for ex in EXCLUDE_DIRS:
        if ex in str(file):
            return True
    return False

# ----------------------------
# NORMALIZATION
# ----------------------------
def normalize_paths(text):
    fixes = {
        "/mnt/mnt/": "/mnt/",
        "/scr/scr/": "/scr/",
        "/c/c/": "/c/",
    }

    changed = True
    while changed:
        changed = False
        for bad, good in fixes.items():
            if bad in text:
                text = text.replace(bad, good)
                changed = True

    return text

# ----------------------------
# FORCE REPLACE
# ----------------------------
def force_replace(text, target):
    # mark all known path types safely
    text = text.replace(PATH_WSL, "__SCR_TEMP_WSL__")
    text = text.replace(PATH_MSYS, "__SCR_TEMP_MSYS__")
    text = text.replace(PATH_LINUX, "__SCR_TEMP_LINUX__")

    # force everything into selected mode
    if target == PATH_WSL:
        text = text.replace("__SCR_TEMP_WSL__", PATH_WSL)
        text = text.replace("__SCR_TEMP_MSYS__", PATH_WSL)
        text = text.replace("__SCR_TEMP_LINUX__", PATH_WSL)

    elif target == PATH_MSYS:
        text = text.replace("__SCR_TEMP_WSL__", PATH_MSYS)
        text = text.replace("__SCR_TEMP_MSYS__", PATH_MSYS)
        text = text.replace("__SCR_TEMP_LINUX__", PATH_MSYS)

    elif target == PATH_LINUX:
        text = text.replace("__SCR_TEMP_WSL__", PATH_LINUX)
        text = text.replace("__SCR_TEMP_MSYS__", PATH_LINUX)
        text = text.replace("__SCR_TEMP_LINUX__", PATH_LINUX)

    return text

# ----------------------------
# PROCESS FILE
# ----------------------------
def process_file(file: Path, target):
    if file.resolve() == SELF or is_excluded(file):
        return 0

    try:
        text = file.read_text(errors="ignore")
    except:
        return 0

    if (
        PATH_WSL not in text
        and PATH_MSYS not in text
        and PATH_LINUX not in text
    ):
        return 0

    new_text = force_replace(text, target)
    new_text = normalize_paths(new_text)

    if new_text == text:
        return 0

    file.write_text(new_text)

    print(f"[✔] {file}")
    return 1

# ----------------------------
# ARG PARSE
# ----------------------------
def parse_args():
    if len(sys.argv) != 2:
        print("Usage: toggle.py -wsl | -msys | -linux")
        sys.exit(1)

    arg = sys.argv[1].lower()

    if arg == "-wsl":
        return PATH_WSL
    elif arg == "-msys":
        return PATH_MSYS
    elif arg == "-linux":
        return PATH_LINUX
    else:
        print("Invalid flag. Use -wsl, -msys, or -linux")
        sys.exit(1)

# ----------------------------
# MAIN
# ----------------------------
def main():
    target = parse_args()

    print(f"[*] Root: {ROOT}")
    print(f"[*] Forcing mode → {target}")

    total = 0

    for file in ROOT.rglob("*"):
        if file.is_file():
            if (
                file.suffix in EXTENSIONS
                or (file.suffix == "" and is_text_file(file))
            ):
                total += process_file(file, target)

    print(f"\n[✔] Done. {total} files updated.")

# ----------------------------
if __name__ == "__main__":
    main()